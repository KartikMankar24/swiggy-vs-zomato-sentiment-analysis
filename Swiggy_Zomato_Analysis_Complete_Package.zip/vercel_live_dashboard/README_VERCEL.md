# Live Dashboard Vercel Deployment Guide

This folder contains the complete, production-ready frontend dashboard for **Swiggy vs Zomato Sentiment & Consumer Journey Mapping**.

## Instant Free Deployment to Vercel (1-Click Command)

1. Open a terminal inside this folder:
   ```bash
   cd "vercel_live_dashboard"
   ```

2. Run the Vercel CLI (or install via `npm i -g vercel` if not installed):
   ```bash
   vercel --prod
   ```

3. Confirm default settings (Press `Enter` through prompts).

Vercel will give you a live production URL immediately, such as:
`https://swiggy-zomato-sentiment-cjm-dashboard.vercel.app`

## Local Preview
Simply double-click `index.html` to open it in any web browser with full interactive Chart.js charts!
